﻿using System;
using System.Collections.Generic;
using Newtonsoft.Json;
using System.Net;
using System.IO;

namespace PKR_ResortServiceTest.Json
{
    public class ServiceGroups
    {
        [JsonProperty("ServiceGroups")]
        public List<ServiceGroup> ServiceGroupName { get; set; }
    }
    public class ServiceGroup
    {
        [JsonProperty("Name")]
        public string ServiceGroupName { get; set; }
    }

    public class Services
    {
        [JsonProperty("Services")]
        public List<Service> ServiceNames { get; set; }
    }
    public class Service
    {
        [JsonProperty("Name")]
        public String Name { get; set; }
    }

    public class Operations
    {
        [JsonProperty("Operations")]
        public List<Operation> OperationNames { get; set; }
    }

    public class Operation
    {
        [JsonProperty("Name")]
        public string Name { get; set; }
    }

    public class Client
    {
        string                      d365OURI;
        PKR_ResortAuthenticate      auth;
        
        public Client(string _d365OURI, PKR_ResortAuthenticate _auth)
        {
            d365OURI = _d365OURI;
            auth = _auth;
        }

        private HttpWebRequest CreateRequest(string _address)
        {
            HttpWebRequest webRequest = (HttpWebRequest)HttpWebRequest.Create(_address);
            webRequest.Method = "POST";
            webRequest.ContentLength = 0;
            webRequest.Headers.Set(PKR_ResortJsonUtil.OAuthHeader, auth.BearerKey);

            return webRequest;
            
        }

        private string ReadJsonResponse(HttpWebRequest _request)
        {
            string jsonString;

            using (HttpWebResponse webResponse = (HttpWebResponse)_request.GetResponse())
            {
                using (Stream stream = webResponse.GetResponseStream())
                {
                    using (StreamReader reader = new StreamReader(stream))
                    {
                        jsonString = reader.ReadToEnd();
                    }
                }
            }

            return jsonString;
        }

        public ServiceGroups GetServiceGroups()
        {
            string serviceGroupAddress = Json.PKR_ResortJsonUtil.GetServiceURI("", d365OURI);
            HttpWebRequest webRequest = CreateRequest(serviceGroupAddress.TrimEnd('/'));
            webRequest.Method = "GET";
            string jsonString = ReadJsonResponse(webRequest);
            ServiceGroups serviceGroups = JsonConvert.DeserializeObject<ServiceGroups>(jsonString);

            return serviceGroups;
            
        }

        public Services GetServices(string _serviceGroup)
        {
            string          serviceGroupAddress = Json.PKR_ResortJsonUtil.GetServiceURI(_serviceGroup, d365OURI);
            HttpWebRequest  webRequest = CreateRequest(serviceGroupAddress);
            webRequest.Method = "GET";
            string jsonString = ReadJsonResponse(webRequest);
            Services services = JsonConvert.DeserializeObject<Services>(jsonString);
            return services;
        }

        public Operations GetOperations(string _serviceGroup, string _resortService)
        {
            string servicePath = _serviceGroup.TrimEnd('/') + "/" + _resortService;
            string serviceGroupAddress = Json.PKR_ResortJsonUtil.GetServiceURI(servicePath, d365OURI);

            HttpWebRequest webRequest = CreateRequest(serviceGroupAddress);
            webRequest.Method = "GET";
            string jsonString = ReadJsonResponse(webRequest);
            Operations operations = JsonConvert.DeserializeObject<Operations>(jsonString);
            return operations;
        }

        public PKR_ResortServiceTest.PKR_ResortTableContract[] GetResorts(
                string _serviceGroup,
                string _service,
                string _operation)
        {
            string servicePath = _serviceGroup.TrimEnd('/') + "/" 
                                + _service.TrimEnd('/') + "/"
                                + _operation;

            string serviceGroupAddress = Json.PKR_ResortJsonUtil.GetServiceURI(servicePath, d365OURI);
            HttpWebRequest webRequest = CreateRequest(serviceGroupAddress);
            string jsonString = ReadJsonResponse(webRequest);
            PKR_ResortServiceTest.PKR_ResortTableContract[] resorts = JsonConvert.DeserializeObject<PKR_ResortServiceTest.PKR_ResortTableContract[]>(jsonString);
            
            return resorts;
        }
    }



}
