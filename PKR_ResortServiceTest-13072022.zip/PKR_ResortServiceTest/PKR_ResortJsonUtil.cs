﻿using System;
using System.Linq;
using System.ServiceModel;
using System.ServiceModel.Channels;


namespace PKR_ResortServiceTest.Json
{
    public class PKR_ResortJsonUtil
    {
        public const string OAuthHeader = "Authorization";
        public static string GetServiceURI (string _servicePath, string _d365OURI)
        {
            return _d365OURI.TrimEnd('/')
                    + "/api/services/"
                    + _servicePath;

        }

        public static EndpointAddress GetEndpointAddress(string _uri)
        {
            EndpointAddress address = new EndpointAddress(_uri);
            return address;

        }

    }
}
